# kiguu kiguu87の説明書を必ずお読みください。
pythonの環境が必要です。
コンパイラ⁽コマンドプロンプト⁾から音声ファイルと同じフォルダないのディレクトリよりpython　kiguuhana.py　にて実行できます。
また、いろいろと頑張っていきますので、私星澤宜嗣が使わしていただいているyoutubeチャンネル(下記のURLにて)の登録よろしくお願い申し上げます。元気が出ます。
いつも大変お世話になり、どうもありがとうございます。すみません
https://www.youtube.com/channel/UC-Uzs-DBrJ8LoEhDZZXqC6A
